
export const CONTRACT_ADDRESS = 'STTESTNETADDRESS';
export const CONTRACT_NAME = 'time-capsule';
export const FULL_CONTRACT_ID = `${CONTRACT_ADDRESS}.${CONTRACT_NAME}`;
